package com.woniuxy.d_interfaceisolation.postive;

public interface Animal {
	public void eat();
}
