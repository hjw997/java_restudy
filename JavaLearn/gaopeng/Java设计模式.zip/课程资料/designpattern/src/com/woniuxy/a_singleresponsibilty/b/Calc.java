package com.woniuxy.a_singleresponsibilty.b;

public abstract class Calc {
	public abstract double calc(double a, double b);
}
