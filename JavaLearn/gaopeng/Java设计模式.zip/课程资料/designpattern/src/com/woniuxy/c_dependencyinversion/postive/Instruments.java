package com.woniuxy.c_dependencyinversion.postive;
//����
interface Instruments {
	public void sound();
}
