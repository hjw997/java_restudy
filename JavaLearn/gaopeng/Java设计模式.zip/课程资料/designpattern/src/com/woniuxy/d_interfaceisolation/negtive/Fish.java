package com.woniuxy.d_interfaceisolation.negtive;

public class Fish implements Animal {

	@Override
	public void eat() {
		System.out.println("�����С�㣬С���Ϻ�ף�Ϻ�׳Ժ���");
	}

	@Override
	public void run() {
		System.out.println("tell me how?? ����");
	}

	@Override
	public void fly() {
		System.out.println("how....");
	}

	@Override
	public void siwm() {
		System.out.println("of course, i can siwm");
	}

}
