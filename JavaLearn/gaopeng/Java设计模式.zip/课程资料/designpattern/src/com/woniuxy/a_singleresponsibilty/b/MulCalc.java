package com.woniuxy.a_singleresponsibilty.b;

public class MulCalc extends Calc{

	@Override
	public double calc(double a, double b) {
		return a * b;
	}

}
