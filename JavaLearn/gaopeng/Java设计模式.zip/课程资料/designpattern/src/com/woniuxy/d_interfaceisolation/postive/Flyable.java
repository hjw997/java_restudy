package com.woniuxy.d_interfaceisolation.postive;

public interface Flyable {
	public void fly();
}
