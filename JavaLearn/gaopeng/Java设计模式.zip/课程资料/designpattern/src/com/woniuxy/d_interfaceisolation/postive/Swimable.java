package com.woniuxy.d_interfaceisolation.postive;

public interface Swimable {
	public void swim();
}
