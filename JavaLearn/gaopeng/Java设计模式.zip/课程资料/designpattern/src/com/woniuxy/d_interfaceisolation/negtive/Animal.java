package com.woniuxy.d_interfaceisolation.negtive;

interface Animal {
	public void eat();
	public void run();
	public void fly();
	public void siwm();
}
