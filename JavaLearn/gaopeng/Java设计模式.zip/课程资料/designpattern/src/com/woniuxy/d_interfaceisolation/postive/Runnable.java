package com.woniuxy.d_interfaceisolation.postive;

public interface Runnable {
	public void run();
}
